# -*- coding:utf-8 -*-
#!/usr/bin/python3

'''
监控数据分析系统所有的爬虫任务
'''

import requests
import json
import pprint
import time

from elasticsearch6 import Elasticsearch
from pandas import tseries
from datetime import datetime


# 调用钉钉机器人@对应负责人
class DingHelp():
    def __init__(self, message):
        global false
        false = ''
        self.message = message
        self.url = 'https://oapi.dingtalk.com/robot/send?access_token=1e8964f7d09b2c8ef23e83202c8bef226b2264a3f0e2d829cece18ef4492ada1'
        self.header = {'Content-Type': 'application/json'}
        self.form = {"msgtype": "text",
                    "text": {"content": ""},
                    "at": {"atMobiles": ["18680359498"],
                    "isAtAll": false}}
        self.form["text"]["content"] = self.message

    def dinghelp(self):
        r = requests.post(self.url, headers=self.header, data=json.dumps(self.form))
        return r.json()


'''
查询ES数据库中的Amazon、SMT、1688、ebay、shopify的榜单数据
'''
class ES_Query1():
    def __init__(self, hosts, port, timeout):
        self.hosts = hosts
        self.port = port
        self.timeout = timeout

    def es_query1(self, index):
        self.index = index

        es = Elasticsearch(hosts=self.hosts, port=self.port, timeout=self.timeout)
        query = {"query": {"match_all": {}},"sort": [{"crawlTime": {"order": "desc"}}]}
        allDoc = es.search(index=self.index, body=query)
        if allDoc['hits']['total'] == 0:
            return 0
        else:
            return allDoc['hits']['hits'][0]['_source']


'''
查询ES数据库中的Amazon、SMT、1688、ebay、shopify的店铺、分类、关键词数据
'''
class ES_Query2():
    def __init__(self, hosts, port, timeout):
        self.hosts = hosts
        self.port = port
        self.timeout = timeout

    def es_query2(self, index, query):
        self.index = index
        self.query = query

        es = Elasticsearch(hosts=self.hosts, port=self.port, timeout=self.timeout)
        query = self.query
        allDoc = es.search(index=self.index, body=query)
        if allDoc['hits']['total'] == 0:
            return 0
        else:
            return allDoc['hits']['hits'][0]['_source']


'''
查看是否执行了榜单爬取任务
'''
def day1(index_y, num):
    EQ_Y = ES_Query1('10.100.1.71', 9200, 50000).es_query1(index_y)
    if EQ_Y == 0:
        return '{}表没有数据'.format(index_y)
    else:
        dt_y = datetime.now()
        date_y = (dt_y - num*tseries.offsets.Day()).strftime('%Y-%m-%d %H:%M:%S')
        if EQ_Y['crawlTime'] > date_y:
            return 'success'
        else:
            return 'fail'


'''
查看是否执行了店铺、分类、关键词监控爬取任务
'''
def day2(index_y, num, query2):
    EQ_Y = ES_Query2('10.100.1.71', 9200, 50000).es_query2(index_y, query2)
    if EQ_Y == 0:
        return '{}表没有数据'.format(index_y)
    else:
        dt_y = datetime.now()
        date_y = (dt_y - num*tseries.offsets.Day()).strftime('%Y-%m-%d %H:%M:%S')
        if EQ_Y['updatedTime'] > date_y:
            return 'success'
        else:
            return 'fail'


'''
获取当天时分秒
'''
def Time():
    times = datetime.now()
    new_time = str(times)
    hour = new_time[11:19]
    return "".join(hour)


if __name__ == '__main__':
    while True:
        current_time = time.localtime(time.time())
        if ((current_time.tm_hour == 9) and (current_time.tm_min == 30) and (current_time.tm_sec == 0)):
            L = []
            '''
            amazon榜单、店铺、分类、关键词
            '''
            # 查看Amazon品类榜单爬取任务是否运行
            amazon_task1 = day1('amazon_base_listing', 1)
            if amazon_task1 == 'success':
                at1 = 'Amazon榜单爬取任务昨日正常执行'
            elif amazon_task1 == 'fail':
                at1 = 'Amazon榜单爬取任务昨日执行异常'
                L.append(at1)

            # 查看Amazon店铺监控爬取任务是否运行
            amazon_task2 = day2('task_manage_info', 7, {"query": {
                                                          "bool": {
                                                            "must": [
                                                            {"match": {
                                                              "saleChannel": "Amazon"
                                                            }},
                                                            {"match": {
                                                              "taskType": "3"
                                                            }}
                                                          ]}
                                                        },"sort": [
                                                          {
                                                            "updatedTime": {
                                                              "order": "desc"
                                                            }
                                                          }
                                                        ]})
            if amazon_task2 == 'success':
                at2 = 'Amazon店铺监控爬取任务上周正常执行'
            elif amazon_task2 == 'fail':
                at2 = 'Amazon店铺监控爬取任务上周执行异常'
                L.append(at2)

            # 查看Amazon分类监控爬取任务是否运行
            amazon_task3 = day2('task_manage_info', 7, {"query": {
                                                          "bool": {
                                                            "must": [
                                                            {"match": {
                                                              "saleChannel": "Amazon"
                                                            }},
                                                            {"match": {
                                                              "taskType": "1"
                                                            }}
                                                          ]}
                                                        },"sort": [
                                                          {
                                                            "updatedTime": {
                                                              "order": "desc"
                                                            }
                                                          }
                                                        ]})
            if amazon_task3 == 'success':
                at3 = 'Amazon分类监控爬取任务上周正常执行'
            elif amazon_task3 == 'fail':
                at3 = 'Amazon分类监控爬取任务上周执行异常'
                L.append(at3)

            # 查看Amazon关键词监控爬取任务是否运行
            amazon_task4 = day2('task_manage_info', 7, {"query": {
                                                          "bool": {
                                                            "must": [
                                                            {"match": {
                                                              "saleChannel": "Amazon"
                                                            }},
                                                            {"match": {
                                                              "taskType": "2"
                                                            }}
                                                          ]}
                                                        },"sort": [
                                                          {
                                                            "updatedTime": {
                                                              "order": "desc"
                                                            }
                                                          }
                                                        ]})
            if amazon_task4 == 'success':
                at4 = 'Amazon关键词监控爬取任务上周正常执行'
            elif amazon_task4 == 'fail':
                at4 = 'Amazon关键词监控爬取任务上周执行异常'
                L.append(at4)

            '''
            smt榜单、店铺、分类、关键词
            '''
            # 查看SMT榜单爬取任务是否运行
            smt_task1 = day1('smt_base_listing', 1)
            if smt_task1 == 'success':
                st1 = 'SMT榜单爬取任务昨日正常执行'
            elif smt_task1 == 'fail':
                st1 = 'SMT榜单爬取任务昨日执行异常'
                L.append(st1)

            # 查看SMT店铺监控爬取任务是否运行
            smt_task2 = day2('task_manage_info', 7, {"query": {
                                                      "bool": {
                                                        "must": [
                                                        {"match": {
                                                          "saleChannel": "SMT"
                                                        }},
                                                        {"match": {
                                                          "taskType": "3"
                                                        }}
                                                      ]}
                                                    },"sort": [
                                                      {
                                                        "updatedTime": {
                                                          "order": "desc"
                                                        }
                                                      }
                                                    ]})
            if smt_task2 == 'success':
                st2 = 'SMT店铺监控爬取任务上周正常执行'
            elif smt_task2 == 'fail':
                st2 = 'SMT店铺监控爬取任务上周执行异常'
                L.append(st2)

            # 查看SMT分类监控爬取任务是否运行
            smt_task3 = day2('task_manage_info', 7, {"query": {
                                                      "bool": {
                                                        "must": [
                                                        {"match": {
                                                          "saleChannel": "SMT"
                                                        }},
                                                        {"match": {
                                                          "taskType": "1"
                                                        }}
                                                      ]}
                                                    },"sort": [
                                                      {
                                                        "updatedTime": {
                                                          "order": "desc"
                                                        }
                                                      }
                                                    ]})
            if smt_task3 == 'success':
                st3 = 'SMT分类监控爬取任务上周正常执行'
            elif smt_task3 == 'fail':
                st3 = 'SMT分类监控爬取任务上周执行异常'
                L.append(st3)

            # 查看SMT关键词监控爬取任务是否运行
            smt_task4 = day2('task_manage_info', 7, {"query": {
                                                      "bool": {
                                                        "must": [
                                                        {"match": {
                                                          "saleChannel": "SMT"
                                                        }},
                                                        {"match": {
                                                          "taskType": "2"
                                                        }}
                                                      ]}
                                                    },"sort": [
                                                      {
                                                        "updatedTime": {
                                                          "order": "desc"
                                                        }
                                                      }
                                                    ]})
            if smt_task4 == 'success':
                st4 = 'SMT关键词监控爬取任务上周正常执行'
            elif smt_task4 == 'fail':
                st4 = 'SMT关键词监控爬取任务上周执行异常'
                L.append(st4)

            '''
            1688分类数据、店铺、分类、关键词
            '''
            # 查看1688分类数据爬取任务是否运行
            taobao_task1 = day1('ali_base_listing', 1)
            if taobao_task1 == 'success':
                tt1 = '1688分类数据爬取任务昨日正常执行'
            elif taobao_task1 == 'fail':
                tt1 = '1688分类数据爬取任务昨日执行异常'
                L.append(tt1)

            # 查看1688店铺监控爬取任务是否运行
            # taobao_task2 = day2('task_manage_info', 7, {"query": {
            #                                               "bool": {
            #                                                 "must": [
            #                                                 {"match": {
            #                                                   "saleChannel": "Alibaba1688"
            #                                                 }},
            #                                                 {"match": {
            #                                                   "taskType": "3"
            #                                                 }}
            #                                               ]}
            #                                             },"sort": [
            #                                               {
            #                                                 "updatedTime": {
            #                                                   "order": "desc"
            #                                                 }
            #                                               }
            #                                             ]})
            # if taobao_task2 == 'success':
            #     tt2 = '1688店铺监控爬取任务上周正常执行'
            # elif taobao_task2 == 'fail':
            #     tt2 = '1688店铺监控爬取任务上周执行异常'
            #     L.append(tt2)
            #
            # # 查看1688分类监控爬取任务是否运行
            # taobao_task3 = day2('task_manage_info', 7, {"query": {
            #                                               "bool": {
            #                                                 "must": [
            #                                                 {"match": {
            #                                                   "saleChannel": "Alibaba1688"
            #                                                 }},
            #                                                 {"match": {
            #                                                   "taskType": "1"
            #                                                 }}
            #                                               ]}
            #                                             },"sort": [
            #                                               {
            #                                                 "updatedTime": {
            #                                                   "order": "desc"
            #                                                 }
            #                                               }
            #                                             ]})
            # if taobao_task3 == 'success':
            #     tt3 = '1688分类监控爬取任务上周正常执行'
            # elif taobao_task3 == 'fail':
            #     tt3 = '1688分类监控爬取任务上周执行异常'
            #     L.append(tt3)
            #
            # # 查看1688关键词监控爬取任务是否运行
            # taobao_task4 = day2('task_manage_info', 7, {"query": {
            #                                               "bool": {
            #                                                 "must": [
            #                                                 {"match": {
            #                                                   "saleChannel": "Alibaba1688"
            #                                                 }},
            #                                                 {"match": {
            #                                                   "taskType": "2"
            #                                                 }}
            #                                               ]}
            #                                             },"sort": [
            #                                               {
            #                                                 "updatedTime": {
            #                                                   "order": "desc"
            #                                                 }
            #                                               }
            #                                             ]})
            # if taobao_task4 == 'success':
            #     tt4 = '1688关键词监控爬取任务上周正常执行'
            # elif taobao_task4 == 'fail':
            #     tt4 = '1688关键词监控爬取任务上周执行异常'
            #     L.append(tt4)

            '''
            ebay-数据采集
            '''
            # 查看ebay爬取任务是否运行
            ebay_task1 = day1('ebay_base_listing', 1)
            if ebay_task1 == 'success':
                et1 = 'ebay爬取任务昨日正常执行'
            elif ebay_task1 == 'fail':
                et1 = 'ebay爬取任务昨日执行异常'
                L.append(et1)

            if L == []:
                L.append("数据分析爬虫任务全部正常运行")
                DingHelp(L).dinghelp()
            else:
                DingHelp(L).dinghelp()
                # pprint.pprint(L)
            time.sleep(5)
        else:
            continue


