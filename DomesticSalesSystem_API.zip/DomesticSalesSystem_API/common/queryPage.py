#!/usr/bin/env python
# -*- coding:utf-8 -*-
# @Time     : 2020/6/2915:28
# @Author   : Dora
# @Email    : peixq@galanz.com

import unittest
import requests

from common import get_domain as URL
from common import get_status as STA

domain = URL.Get_Domain().Domain()

class queryPage(unittest.TestCase):
    #目标管理-指标任务接口-指标详情-/indicatorTask/batchExPort
    def setUp(self):
        self.url = domain+'/b2bsfa/indicatorTask/queryPage/'

        self.headers = {
            "Content-Type":"application/json;charset=UTF-8"
        }

        #print(self.url,'\n')
    def test_PullIndicator(self):
        data = {
            "pageNo":1,
            "pageSize":10
        }
        r = requests.get(url=self.url,data=data,headers=self.headers)
        STA.Get_Status().get_status(r.status_code)
        print(r.text)