#!/usr/bin/env python
# -*- coding:utf-8 -*-
# @Time     : 2020/6/2815:42
# @Author   : Dora
# @Email    : peixq@galanz.com

def GetToken():
    token = "eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJleHAiOjE1OTM5Mzg0OTAsInVzZXJuYW1lIjoiZ2FsYW56In0.oGJH-z0H4doI6FFdJEJek4BsIfyIYRj8WNy3jCfgMvY"
    return token
