#!/usr/bin/python
#coding=utf8
import unittest
from unittest import TestLoader
import sys
import os

case_path = os.path.abspath(os.path.dirname(os.path.dirname(__file__)))

def suite():
    suite = unittest.defaultTestLoader.discover(case_path, pattern="*.py", top_level_dir=case_path)
    return suite