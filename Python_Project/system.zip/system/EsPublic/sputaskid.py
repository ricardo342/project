# -*- coding:utf-8 -*-
#!/usr/bin/python3

from queue import Queue
from pandas import *
from pandas import tseries
import time
import datetime
import pymysql
import itertools
import requests
import json


'''
监控任务逻辑
1.获取正式环境中创建时间为两个小时内的定时刊登处理报告数据
2.放入队列中等待五个小时后，以先进先出原则逐条处理数据
3.处理过程中判断任务ID是否为空，为空则输出该处理报告记录
4.队列中数据全部处理完证候再次执行1-3步骤
5.检查/home/python_task/EsPublic/error_file路径下是否存在该程序执行期间file_time后缀的文件，存在则提示有任务ID为空的处理报告
'''


# 调用钉钉机器人@对应负责人
class DingHelp():
    def __init__(self, message):
        global false
        false = ''
        self.message = message
        self.url = 'https://oapi.dingtalk.com/robot/send?access_token=7d867c58795e8e11fa3e197b55771c01e68702364f73ae7ac852219e35873567'
        self.header = {'Content-Type': 'application/json'}
        self.form = {"msgtype": "text",
                    "text": {"content": ""},
                    "at": {"atMobiles": ["18175723582", "13714323733"],
                    "isAtAll": false}}
        self.form["text"]["content"] = self.message

    def dinghelp(self):
        r = requests.post(self.url, headers=self.header, data=json.dumps(self.form))
        return r.json()


# 获取生产环境数据库数据
class Get_Sql():
    def __init__(self, database, host, user, password, charset='utf8'):
        self.host = host
        self.user = user
        self.password = password
        self.database = database
        self.charset = charset

    def conn_sql(self, sql):
        self.sql = sql
        con = pymysql.connect(
            host=self.host,
            user=self.user,
            password=self.password,
            database=self.database,
            charset=self.charset
        )

        cursor = con.cursor()
        cursor.execute(self.sql)
        results = cursor.fetchall()
        list_sql = [str(i) for i in itertools.chain(*results)]
        return list_sql


# 获取特定的日期时间
def GetDate(date, num=0):
    dt =datetime.datetime.now()
    dt_date = (dt + num*tseries.offsets.Hour()).strftime(date)
    return dt_date


# 将数据库数据放置到队列中以先入先出原则逐条处理数据
def main():
    start_time = GetDate('%Y-%m-%d %H:%M:%S', -7)
    middle_time = GetDate('%Y-%m-%d %H:%M:%S', -6)
    end_time = GetDate('%Y-%m-%d %H:%M:%S', -5)
    file_time = GetDate('%y%m%d-%H%M%S', -7)
    # 查询当前时间往前延6-7小时内自动刊登-定时刊登中的模板编号
    num_sql = """SELECT template_id FROM template_queue \
    WHERE sale_channel = 'Amazon' \
    AND template_id IS NOT NULL \
    AND STATUS = 2 \
    AND timing_type = 1 \
    AND last_update_date between '{0}' and '{1}' limit 10;""".format(start_time, middle_time)
    gs_nums = Get_Sql('pmsSale', '192.168.2.230', 'readonly', '!QAZxsw2').conn_sql(num_sql)

    # 根据模板编号查询taskid为空的处理报告
    gs_reports = []
    for gs_num in gs_nums:
        resport_sql = """SELECT * FROM amazon_process_report \
        WHERE relation_id = '{0}' \
        AND relation_type='Template' \
        AND feed_type='_POST_PRODUCT_DATA_' \
        AND task_id is null \
        AND result_msg is null \
        AND creation_date between '{1}' and '{2}';""".format(gs_num, start_time, end_time)
        gs_report = Get_Sql('pmsSale', '192.168.2.230', 'readonly', '!QAZxsw2').conn_sql(resport_sql)
        gs_reports.append(gs_report)

    if len(gs_reports) == 0:
        msg1 = 'Amazon自动刊登昨天生成的处理报告数据正常'
        # current_time = time.localtime(time.time())
        # if ((current_time.tm_hour == 11) and (current_time.tm_min == 31) and (current_time.tm_sec == 0)):
        #     print(msg1)
        DingHelp(msg1).dinghelp()
    elif len(gs_reports) > 0:
        # msg2 = 'Amazon自动刊登此时间段内有taskId为空的处理报告,有问题的数据如下: '
        # print(msg2, end='\n')
        # print(gs_reports)
        DingHelp('有taskId为空的处理报告,请到数据库/home/python_task/EsPublic/error_file\
                 下查看最新日期的abnormal_record文本文件').dinghelp()
        with open('/home/python_task/EsPublic/error_file/abnormal_record{0}.txt'.format(file_time), 'w') as f:
            f.writelines(gs_reports)

if __name__ == '__main__':
    main()