#!/usr/bin/env python
# -*- coding: utf-8 -*-

def codeRespon(code):
    if code == '200' :
        print("status=200   ok")
    elif code == '201' :
        print("statue=201   Created")
    elif code == '401' :
        print("status=401   Unauthorized")
    elif code == '403' :
        print("statue=403   Forbidden")
    elif code == '404' :
        print("status=404   Not Found")
    elif code == '500' :
        print("statue=500   Internal Server error")
    elif code == '503' :
        print("status=503   Server Unavailable")
    elif code == '504' :
        print("status=504   Gateway Timeout")
    else:
        print("status=%r  Failed"%code)



#codeRespon(304)











'''
import unittest
from assertpy import assert_that

class codeRespon(unittest.TestCase):
    def __init__(self,file_name):
        self.file_name = file_name

    def codeRespon(self,file_name):  
        if assert_that(file_name).is_equal_to(200):
            return ("statue=200   ok",file_name)
        elif assert_that(file_name).is_equal_to(201):
            return ("statue=201   Created")
        elif assert_that(file_name).is_equal_to(401):
            return ("status=401   Unauthorized")
        elif assert_that(file_name).is_equal_to(403):
            return ("statue=403   Forbidden")
        elif assert_that(file_name).is_equal_to(404):
            return ("status=404   Not Found")
        elif assert_that(file_name).is_equal_to(500):
            return ("statue=500   Internal Server error")
        elif assert_that(file_name).is_equal_to(503):
            return ("status=503   Server Unavailable")
        elif assert_that(file_name).is_equal_to(504):
            return ("status=504   Gateway Timeout")
        else:
            return ('fail')
    '''