#!/usr/bin/python
#coding=utf8

import sqlite3

class Select_Db():
    def __init__(self):
        self.conn = sqlite3.connect('test.db')
        self.cursor = self.conn.cursor()

    def select_db(self, table):
        self.table = self.cursor.execute('select * from table')
        self.values = self.cursor.fetchall()
        self.cursor.close()
        self.conn.close()