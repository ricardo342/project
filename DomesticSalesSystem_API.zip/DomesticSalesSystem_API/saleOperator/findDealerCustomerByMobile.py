#!/usr/bin/python
#coding=utf8
import logging
logging.basicConfig(level=logging.DEBUG, format=' %(asctime)s - %(levelname)s- %(message)s')
# logging. disable(logging.CRITICAL)    # 禁用日志
logging.debug('Start of program')

import unittest
import requests
import json
import HTMLTestRunner
import os, sys
import re
from assertpy import assert_that
import numpy as np
import pandas as pd

from common import get_domain as c
from common import codeRespon as s
from common import organize_json as oj

domain = c.Get_Domain().Domain()

class findDealerCustomerByMobile(unittest.TestCase):
    def setUp(self):
        self.url = domain + "/b2bsfa/saleOperator/findDealerCustomerByMobile"
        self.headers = {'Content-Type': 'application/json;charset=UTF-8'}
        

    def test_findDealerCustomerByMobile(self):
        self.form = {'mobile': '15750710052'}
        r = requests.get(self.url, headers=self.headers, params=self.form)
        print(r.text)
        code = r.status_code
        codes = oj.Organize_Json("./saleOperator/r.json", r.text).organize_json()
        print(code)
        s.codeRespon(codes)
        # print(code)
                   
        try:
            assert_that(codes).is_equal_to('200')
            with open("./saleOperator/.r.txt", "w") as rs:
                rs.write(r.text)
            f = open("./saleOperator/.r.txt", "r")
            alllines = f.readlines()
            f.close()
            f = open("./saleOperator/.r.txt", "w+")
            for eachline in alllines:
                a = re.sub('null', 'None', eachline)
                f.writelines(a)
            f.close()
            # null=None
            find = open('./saleOperator/findDealerCustomerByMobile.txt', "r", encoding = "utf-8")
            rlt = open('./saleOperator/.r.txt', "r")
            result = rlt.read()
            report = eval(result)
            #print(report)
            List = []
            L = list(find)
            for i in L:
                i = i.replace("\n", "")
                List.append(i)
            Report = []    
            for j in report.keys():
                Report.append(j)

            for k in report['data'][0]:
                Report.append(k)

            print(Report)
            print(List)

            if Report.sort() == List.sort():
                print("Ok")
            else:
                print("No Ok")

            find.close()
            f.close()
            rlt.close()
            os.remove('./saleOperator/.r.txt')

        except AssertionError:
            print("返回数据没有断言中的某个字段")
        finally:
            find.close()
       
def suite():
    suite = unittest.TestSuite()
    suite.addTest(findDealerCustomerByMobile("test_findDealerCustomerByMobile"))
    return suite

if __name__ == "__main__":
    # re = open("result.html", "wb")
    runner = unittest.TextTestRunner()
    runner.run(suite())
    # re.close()
        

logging.debug('End of program')