# -*- coding:utf-8 -*-
#!/usr/bin/python3
'''
新用户系统往旧用户系统同步账号
'''
import requests
import json

s = '170479'
datas = {"args": ""}
data1 = {'employeeNos': ['']}
data1['employeeNos'] = s
datas["args"] = str(data1)

def employee():
    url = 'http://192.168.3.165:8001/usermgt-n/usermgt_old/oldemployee/syncHr2Usermgt'
    header = {'Content-type': 'application/json',
              'Authorization': '5df26666b185fbf0b3437482125d340e'}
    form = datas
    print(form)
    r = requests.post(url, headers=header, data=json.dumps(form))
    return r.json()

if __name__ == '__main__':
    s = employee()
    print(s)