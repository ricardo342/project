#!/usr/bin/python
#coding=utf8
import logging
logging.basicConfig(level=logging.DEBUG, format=' %(asctime)s - %(levelname)s- %(message)s')
# logging. disable(logging.CRITICAL)    # 禁用日志
logging.debug('Start of program')

import unittest
import requests
import json
import HTMLTestRunner
from assertpy import assert_that
import os
import re

from common import get_domain as c
from common import codeRespon as s
from common import organize_json as oj

domain = c.Get_Domain().Domain()

class findSaleOperatorList(unittest.TestCase):
    def setUp(self):
        self.url = domain + "/b2bsfa/saleOperator/findSaleOperatorList"
        self.headers = {'Content-Type': 'application/json;charset=UTF-8'}
        
        # open('findSaleOperatorList.json', encoding = "utf-8").close()

    def test_findSaleOperatorList(self):
        with open('./saleOperator/findSaleOperatorList.json', "r", encoding = "utf-8") as f:
            json_data = json.load(f)
        # print(json_data)
        self.form = json_data
        r1 = requests.post(self.url, headers=self.headers, data=json.dumps(self.form))
        code = r1.status_code
        codes = oj.Organize_Json("./saleOperator/r.json", r1.text).organize_json()
        print(code)
        s.codeRespon(codes)
        with open("./saleOperator/.r1.txt", "w") as rs:
            rs.write(r1.text)
        f = open("./saleOperator/.r1.txt", "r")
        alllines = f.readlines()
        f.close()
        f = open("./saleOperator/.r1.txt", "w+")
        for eachline in alllines:
            a = re.sub('null', 'None', eachline)
            f.writelines(a)
        f.close()
        # print(code)
        try:
            # null=None
            assert_that(codes).is_equal_to('200')
            find = open('./saleOperator/findSaleOperatorList.txt', "r", encoding = "utf-8")
            rlt = open('./saleOperator/.r1.txt', "r")
            result = rlt.read()
            report = eval(result)
            print(report)
            List = []
            L = list(find)
            for i in L:
                i = i.replace("\n", "")
                List.append(i)
            Report = []    
            for j in report.keys():
                Report.append(j)

            for k in report['data'].keys():
                Report.append(k)
            
            for t in report['data']['result'][0].keys():
                Report.append(t)

            print(Report)
            print(List)

            if Report.sort() == List.sort():
                print("Ok")
            else:
                print("No Ok")

            find.close()
            f.close()
            rlt.close()
            os.remove('./saleOperator/.r1.txt')

        except AssertionError:
            print("返回数据没有断言中的某个字段")
        finally:
            find.close()
       
def suite():
    suite = unittest.TestSuite()
    suite.addTest(findSaleOperatorList("test_findSaleOperatorList"))
    return suite

if __name__ == "__main__":
    # re = open("report.html", "wb")
    runner = unittest.TextTestRunner()
    runner.run(suite())
    # re.close()

logging.debug('End of program')