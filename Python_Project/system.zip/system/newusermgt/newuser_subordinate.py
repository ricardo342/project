# -*- coding:utf-8 -*-
#!/usr/bin/python3

'''
查询新用户系统用户下级人员
'''
import requests
import pprint
import json

'''
查看账号在该页面下的权限
'''
def employee():
    url = 'http://192.168.3.162/usermgt-n/sys/roledatapermission/getRDPEmployees'
    header = {'Content-Type': 'application/json',
              'Authorization': '5df26666b185fbf0b3437482125d340e'}
    form = {"args": "{'employeeNo':'1289','menuCode':'3010100'}"}

    r = requests.post(url, headers=header, data=json.dumps(form))
    return r.json()

'''
查看该组织架构id的下级员工
'''
def deptid():
    url = 'http://192.168.3.165:8181/usermgt-n/hr/employee/listNextEmployeeByDeptId'
    header = {'Content-Type': 'application/json',
              'Authorization': '5df26666b185fbf0b3437482125d340e'}
    form = {"args": "314555583"}

    r = requests.post(url, headers=header, data=json.dumps(form))
    return r.json()

if __name__ == '__main__':
    result = employee()
    deptids = deptid()
    pprint.pprint(result)