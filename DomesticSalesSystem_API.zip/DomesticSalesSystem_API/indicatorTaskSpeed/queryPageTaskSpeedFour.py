#!/usr/bin/python
#coding=utf8
import logging
logging.basicConfig(level=logging.DEBUG, format=' %(asctime)s - %(levelname)s- %(message)s')
# logging. disable(logging.CRITICAL)    # 禁用日志
logging.debug('Start of program')

import unittest
import requests
import json
import HTMLTestRunner
from assertpy import assert_that

from common import get_domain as c
from common import codeRespon as s
from common import organize_json as oj

domain = c.Get_Domain().Domain()

class queryPageTaskSpeedFour(unittest.TestCase):
    def setUp(self):
        #self.url = domain + "/indicatorTaskSpeed/queryPageTaskSpeedFour"
        #self.headers = {'Content-Type': '*/*'}
        #self.form = {'id': 'string'}
        print('*'*60 + "BEGIN TEST audit" + '*'*60)

    def test_queryPageTaskSpeedFour(self):
        self.url = domain + "/b2bsfa/indicatorTaskSpeed/queryPageTaskSpeedFour"
        self.form = {
            'currentNo':'1',
            'pageSize':'100',
            'taskId':'0001'
        }
        self.headers = {"Content-Type":"application/json;charset=UTF-8"}

        r = requests.get(self.url,params=self.form,headers=self.headers)
        code = r.status_code    #获取status code
        # s.codeRespon(code)      #打印status code的具体内容
        codes = oj.Organize_Json("./indicatorTaskSpeed/r.json", r.text).organize_json()
        print(code)
        s.codeRespon(codes)
        print(r.text)
        try:
            assert_that(codes).is_equal_to('200')
            #第二次断言返回的body,当前只判断返回的key和类型
            assert_that(r.text).contains("code","data","message").is_type_of(str)                              
        except AssertionError as e:
            raise AssertionError(e)
            
       

if __name__ == '__main__':
    runTest = queryPageTaskSpeedFour()
    runTest.test_queryPageTaskSpeedFour()
        

logging.debug('End of program')