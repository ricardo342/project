# -*- coding:utf-8 -*-
#!/usr/bin/python3

'''
设置定时停止locust压测脚本
'''

from selenium import webdriver
import time

# 打开谷歌浏览器
driver = webdriver.Chrome()
# 打开locust
driver.get("http://localhost:8089/")
time.sleep(2)

# 定位xpath元素操作locust界面
def get_xpath(xpath, method, *args):
    if method == 'click':
        driver.find_element_by_xpath(xpath).click()
        time.sleep(2)
    elif method == 'sendkeys':
        driver.find_element_by_xpath(xpath).click()
        driver.find_element_by_xpath(xpath).send_keys(*args)
        time.sleep(2)

# 输入总用户数
get_xpath('//*[@id="user_count"]', 'sendkeys', 80)

# 输入每秒生成用户数
get_xpath('//*[@id="spawn_rate"]', 'sendkeys', 1)

# 启动压测脚本
get_xpath('//*[@id="swarm_form"]/button', 'click')

# 设定时间停止压测脚本
'''
设置时间
'''
def Time(num, ltime):
    if ltime == 'sec':
        s = num
    elif ltime == 'min':
        s = num * 60
    elif ltime == 'hour':
        s = num * 60 * 60

    return s

seco = Time(3, 'hour')
time.sleep(seco)
get_xpath('//*[@id="box_stop"]/a[1]', 'click')
