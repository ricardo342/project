#!/usr/bin/python
#coding=utf8

import json
import os

class Organize_Json():
    def __init__(self, file, rtext):
        self.file = file
        self.rtext = rtext

    def organize_json(self):
        l = open(self.file, "w")
        l.write(self.rtext)
        l.close()
        t_str = open(self.file).read()
        t_json = json.loads(t_str)
        self.codes = t_json["code"]
        os.remove(self.file)
        return self.codes