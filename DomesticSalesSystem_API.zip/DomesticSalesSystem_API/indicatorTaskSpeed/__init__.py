#!/usr/bin/python
#coding=utf8
print("indicatorTaskSpeed")