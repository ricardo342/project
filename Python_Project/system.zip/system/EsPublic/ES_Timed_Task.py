# -*- coding:utf-8 -*-
#!/usr/bin/python3

'''
监控刊登系统所有平台改停产存档库存为0的定时任务，
记录每个平台每天跑多少数据
所用数据库表如下：
shopee：feed_task_3(叶长丰)
wish：wish_operate_log(叶长丰)
shopify：shopify_operate_log(叶长丰)
ebay: feed_task_2(余长茂)
aliexpress: aliexpress_product_log(刘成)
joom: 暂时没有处理报告
walmart: 暂时没有处理报告
Lazada: 库存和价格是一起的 无法分辨出是改了价格还是库存
Amazon: 改库存还有别的状态也会改，也分辨不了是停产存档还是别的状态
'''

import requests
import json
import pymysql

# url = "https://oapi.dingtalk.com/robot/send?access_token=554872de66205d9683d8e4ecf4614f4d3e9968d448235d4368bbcf09c65d0f1d"

# 调用钉钉机器人
class DingHelp():
    def __init__(self, message, mobile):
        # python无法处理false，因此需要先给false赋值并设置为全局变量
        global false
        false = ''
        self.message = message
        self.mobile = mobile
        # 设置钉钉机器人的webhook
        self.url = 'https://oapi.dingtalk.com/robot/send?access_token=1e8964f7d09b2c8ef23e83202c8bef226b2264a3f0e2d829cece18ef4492ada1'
        self.header = {'Content-Type': 'application/json'}
        self.form = {"msgtype": "text",
                    "text": {"content": ""},
                    "at": {"atMobiles": ["18680359498"],
                    "isAtAll": false}}
        # 修改请求参数中的消息(context)和手机号(atMobiles)
        self.form["text"]["content"] = self.message
        self.form["at"]["atMobiles"] = self.mobile

    def dinghelp(self):
        # 根据url，headers&data调用接口并返回数据
        r = requests.post(self.url, headers=self.header, data=json.dumps(self.form))
        return r.json()


# 查询数据库类
class Query_Mysql():
    def __init__(self):
        pass

    def query_mysql(self):
        pass


# shopee监控类
class Shopee():
    def __init__(self):
        pass

    def shopee(self):
        pass


# wish监控类
class Wish():
    def __init__(self):
        pass

    def wish(self):
        pass


# shopify监控类
class Shopify():
    def __init__(self):
        pass

    def shopify(self):
        pass


# ebay监控类
class Ebay():
    def __init__(self):
        pass

    def ebay(self):
        pass


# aliexpress监控类
class Aliexpress():
    def __init__(self):
        pass

    def aliexpress(self):
        pass


# joom监控类(暂无)
class Joom():
    def __init__(self):
        pass

    def joom(self):
        pass


# walmart监控类(暂无)
class Walmart():
    def __init__(self):
        pass

    def walmart(self):
        pass


# lazada监控类(暂无)
class Lazada():
    def __init__(self):
        pass

    def lazada(self):
        pass


# amazon监控类(暂无)
class Amazon():
    def __init__(self):
        pass

    def amazon(self):
        pass


if __name__ == '__main__':
    pass
