#!/usr/bin/python
#coding=utf8
import logging
logging.basicConfig(level=logging.DEBUG, format=' %(asctime)s - %(levelname)s- %(message)s')
# logging. disable(logging.CRITICAL)    # 禁用日志
logging.debug('Start of program')

import unittest
import requests
import json
import HTMLTestRunner
from assertpy import assert_that

from common import get_domain as c
from common import codeRespon as s
from common import organize_json as oj

domain = c.Get_Domain().Domain()

class batchUpdateSaleOperator(unittest.TestCase):
    def setUp(self):
        self.url = domain + "/b2bsfa/saleOperator/batchUpdateSaleOperator"
        # self.url = "http://ec2-52-83-156-42.cn-northwest-1.compute.amazonaws.com.cn:30034/b2bsfa/saleOperator/delSaleOperator"
        self.headers = {'Content-Type': 'application/json;charset=UTF-8'}
        
    def test_batchUpdateSaleOperator(self):
        
        with open('./saleOperator/batchUpdateSaleOperator.json', "r", encoding='utf8') as e:
            json_data = json.load(e)
        
        list = [json_data]
        # print(list)
       
        r = requests.post(self.url, headers=self.headers, data=json.dumps(list))
        code = r.status_code
        codes = oj.Organize_Json("./saleOperator/r.json", r.text).organize_json()
        print(code)
        s.codeRespon(codes)
        print(r.text)
        try:
            assert_that(codes).is_equal_to('200')
            assert_that(r.text).contains("code","data","message").is_type_of(str)
        except AssertionError as e:
            raise AssertionError(e)


def suite():
    suite = unittest.TestSuite()
    suite.addTest(batchUpdateSaleOperator("test_batchUpdateSaleOperator"))
    return suite

if __name__ == "__main__":
    # re = open("result.html", "wb")
    runner = unittest.TextTestRunner()
    runner.run(suite())
    # re.close()        

logging.debug('End of program')