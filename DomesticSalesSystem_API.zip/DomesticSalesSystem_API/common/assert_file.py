#!/usr/bin/python
#coding=utf8

import os
import re

class Assert_File():
    def __init__(self, assertfile, reportfile, r):     # assertfile为提取断言key的文件， reportfile为复制swagger返回数据的文件，都要加路径
        self.assertfile = assertfile
        self.reportfile = reportfile
        self.r = r.text

    def assert_file(self):
        with open(self.assertfile, "w") as rs:
            rs.write(self.r)
        f = open(self.assertfile, "r")
        alllines = f.readlines()
        f.close()
        f = open(self.assertfile, "w+")
        for eachline in alllines:
            a = re.sub('null', 'None', eachline)
            f.writelines(a)
        f.close()
        # null=None
        find = open(self.reportfile, "r", encoding = "utf-8")
        rlt = open(self.assertfile, "r")
        result = rlt.read()
        report = eval(result)
        print(report)
        List = []
        L = list(find)
        for i in L:
            i = i.replace("\n", "")
            List.append(i)
        Report = []    
        for j in report.keys():
            Report.append(j)

        for k in report['data'].keys():
            Report.append(k)

        print(Report)
        print(List)

        if Report == List:
            print("Ok")
        else:
            print("No Ok")

        find.close()
        f.close()
        rlt.close()
        os.remove(self.assertfile)