#!/usr/bin/python
#coding=utf8
import logging
logging.basicConfig(level=logging.DEBUG, format=' %(asctime)s - %(levelname)s- %(message)s')
# logging. disable(logging.CRITICAL)    # 禁用日志
logging.debug('Start of program')

import unittest
import requests
import json
import HTMLTestRunner
from assertpy import assert_that

from common import get_domain as c
from common import codeRespon as s
from common import organize_json as oj


domain = c.Get_Domain().Domain()


class audit(unittest.TestCase):
    def setUp(self):
        #self.url = domain + "/indicatorTaskSpeed/audit"
        #self.headers = {'Content-Type': '*/*'}
        #self.form = {'speedIds': '0001',
        #            'auditStatus':'审核中',
        #            'auditUserName':'Mr.高',
        #            'auditRemark':'NA'
        #}
        print('*'*60 + "BEGIN TEST audit" + '*'*60)
    
    def test_audit(self):
        self.url = domain + "/b2bsfa/indicatorTaskSpeed/audit"
        self.form = {'speedIds': '0001',
                    'auditStatus':'审核中',
                    'auditUserName':'Mr.高',
                    'auditRemark':'NA'
        }
        self.headers = {"Content-Type":"application/json;charset=UTF-8"}
        
        r = requests.get(self.url,params=self.form,headers=self.headers)
        code = r.status_code    #第一次断言：获取status code
        # s.codeRespon(code)      #打印status code的具体内容
        codes = oj.Organize_Json("./indicatorTaskSpeed/r.json", r.text).organize_json()
        print(code)
        s.codeRespon(codes)
        print(r.text)


        #assert_that(code).is_equal_to(200)
 
        try:
            assert_that(codes).is_equal_to('200')
            #第二次断言返回的body,当前只判断返回的key和类型
            assert_that(r.text).contains("code","data","message").is_type_of(str)                              
        except AssertionError as e:
            raise AssertionError(e)
            print("TEST Failed")

if __name__ == '__main__':
    runTest = audit()
    runTest.test_audit()
    #unittest.main()

 



logging.debug('End of program')


