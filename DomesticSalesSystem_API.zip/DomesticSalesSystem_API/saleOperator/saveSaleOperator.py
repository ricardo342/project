#!/usr/bin/python
#coding=utf8
import logging
logging.basicConfig(level=logging.DEBUG, format=' %(asctime)s - %(levelname)s- %(message)s')
# logging. disable(logging.CRITICAL)    # 禁用日志
logging.debug('Start of program')

import unittest
import requests
import json
import HTMLTestRunner
from assertpy import assert_that
import re

from common import get_domain as c
from common import codeRespon as s
from common import organize_json as oj

domain = c.Get_Domain().Domain()

class saveSaleOperator(unittest.TestCase):
    def setUp(self):
        self.url = domain + "/b2bsfa/saleOperator/saveSaleOperator"
        self.headers = {'Content-Type': 'application/json;charset=UTF-8'}
        
        # open('saveSaleOperator.json', encoding = "utf-8").close()

    def test_saveSaleOperator(self):
        with open('./saleOperator/saveSaleOperator.json', "r", encoding="utf-8") as c:
            json_data = json.load(c)
        # print(type(json_data))
        
        self.form = json_data
        r = requests.post(self.url, headers=self.headers, data=json.dumps(self.form))
        code = r.status_code
        # print(code)
        #print(r.text)
        codes = oj.Organize_Json("./saleOperator/r.json", r.text).organize_json()
        print(code)
        s.codeRespon(codes)
        print(r.text)
        try:
            assert_that(codes).is_equal_to('200')
            assert_that(r.text).contains("code","data","message").is_type_of(str)
        except AssertionError as e:
            raise AssertionError(e)
       
def suite():
    suite = unittest.TestSuite()
    suite.addTest(saveSaleOperator("test_saveSaleOperator"))
    return suite

if __name__ == "__main__":
    # re = open("result.html", "wb")
    runner = unittest.TextTestRunner()
    runner.run(suite())
    # re.close()
        

logging.debug('End of program')