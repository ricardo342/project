# -*- coding:utf-8 -*-
#!/usr/bin/python3

'''
进行SPU管理的商标词、侵权词校验接口压测
商标词表数据较多，存在ES数据库中，侵权词数据较少，存在MySQL中
侵权词库数据较少缓存到redis中

业务逻辑如下：新增和编辑SPU时需要将编辑页中的所有信息拼接成字符
串后分别调用商标词、侵权词校验接口来逐条校验是否有和商标词库、侵
权词库重复，不重复保存成功，重复则提示报错

压测思路如下：
使用python+locust来并发测试，从SPU管理数据表中取大批量数据和设
置线程数来对接口进行负载，获取不同数据量和线程数下接口响应时间以及
记录每个商标词校验不通过的次数，取次数最多的前五千个商标词
'''

'''
from locust import Locust, HttpUser, TaskSet, task, between
'''
import locust
import requests
import pymysql
import itertools
import random
import string
import pprint
import json
import csv
import codecs
import time

from elasticsearch6 import Elasticsearch
from requests_toolbelt import MultipartEncoder
from pandas import tseries
from datetime import datetime

# host = 'http://192.168.3.198:8883'

# 增删改查MySQL数据库数据
class Data_Sql():
    def __init__(self, database, host, user, password, charset='utf8'):
        self.host = host
        self.user = user
        self.password = password
        self.database = database
        self.charset = charset

    def data_sql(self, methods, sql):
        self.methods = methods
        self.sql = sql

        con = pymysql.connect(
            host=self.host,
            user=self.user,
            password=self.password,
            database=self.database,
            charset=self.charset)

        # 查询数据库数据
        if self.methods == 'select':
            cursor = con.cursor()
            cursor.execute(self.sql)
            cursor.close()
            results = cursor.fetchall()
            list_sql = [i for i in itertools.chain(*results)]
            return list_sql

        # 新增修改删除数据库数据
        elif self.methods == 'insert' or self.methods == 'update' or self.methods == 'delete':
            cursor = con.cursor()
            cursor.execute(self.sql)
            cursor.close()
            con.commit()
            con.close()


# 从ES数据库获取商标词库数据
class Data_Es():
    def __init__(self, hosts, port, timeout):
        self.hosts = hosts
        self.port = port
        self.timeout = timeout

    def data_es(self, index, querys):
        self.index = index
        self.query = querys

        es = Elasticsearch(hosts=self.hosts, port=self.port, timeout=self.timeout)
        query = self.query
        allDoc = es.search(index=self.index, body=query)
        if allDoc['hits']['total'] == 0:
            return 0
        else:
            return allDoc['hits']['hits'][0]['_source']

# # 获取数据完整的所有spu
# query_spu = "SELECT spu FROM spu_official WHERE off_complement = '1';"
# spus = Data_Sql('erp_product', '192.168.4.87', 'root', 'admin0808').data_sql('select', query_spu)
# spu = spu_num = spus[random.randint(1, len(spus))]
# # 拼接spu文案
# query_sql = "SELECT cn_customs, en_customs, title, amazon_title, \
#            must_keyword, description, short_description FROM spu_official \
#            WHERE spu = '{0}' AND off_complement = '1';".format(spu)
# sql = Data_Sql('erp_product', '192.168.4.87', 'root', 'admin0808').data_sql('select', query_sql)
# sql_filter = list(filter(None, sql))
# s = ''.join(sql_filter)

# 将数据导出成csv文件
def file_csv(file_path, data):
    f_csv = codecs.open(file_path, 'w+', 'utf-8')
    writer = csv.writer(f_csv, delimiter=';', quotechar='"', quoting=csv.QUOTE_MINIMAL)
    for i in data:
        writer.writerow(i)


class CheckBrand_CheckinFringement(locust.TaskSet, Data_Es, Data_Sql):
    def on_start(self):
        global spu, s
        print('start')
        # 获取数据完整的所有spu
        query_spu = "SELECT spu FROM spu_official WHERE off_complement = '1';"
        spus = Data_Sql('erp_product', '192.168.4.87', 'root', 'admin0808').data_sql('select', query_spu)
        spu = spus[random.randint(1, len(spus) - 1)]
        # 拼接spu文案
        query_sql = "SELECT cn_customs, en_customs, title, amazon_title, \
                                  must_keyword, description, short_description FROM spu_official \
                                  WHERE spu = '{0}' AND off_complement = '1';".format(spu)
        sql = Data_Sql('erp_product', '192.168.4.87', 'root', 'admin0808').data_sql('select', query_sql)
        sql_filter = list(filter(None, sql))
        s = ''.join(sql_filter)

    # 创建商标词(ES)接口行为类
    # @locust.task(1)
    # def checkbrand(self):
        '''
        # 获取数据完整的所有spu
        query_spu = "SELECT spu FROM spu_official WHERE off_complement = '1';"
        spus = Data_Sql('erp_product', '192.168.4.87', 'root', 'admin0808').data_sql('select', query_spu)
        spu = spus[random.randint(1, len(spus)-1)]
        # 拼接spu文案
        query_sql = "SELECT cn_customs, en_customs, title, amazon_title, \
                          must_keyword, description, short_description FROM spu_official \
                          WHERE spu = '{0}' AND off_complement = '1';".format(spu)
        sql = Data_Sql('erp_product', '192.168.4.87', 'root', 'admin0808').data_sql('select', query_sql)
        sql_filter = list(filter(None, sql))
        s = ''.join(sql_filter)
        '''
        # self.url = '/commonConfig/checkBrand'
        # self.form = MultipartEncoder({"content": "{0}".format(s),
        #              "sku": "{0}".format(spu)})
        # print("checkbrand: {0}".format(spu))
        # t = datetime.now()
        # # r = self.client.post(self.url, data=self.form, headers={'Content-Type': self.form.content_type})
        # # 断言接口是否报错
        # with self.client.post(url=self.url, data=self.form,
        #                       headers={'Content-Type': self.form.content_type},
        #                       timeout=10, catch_response=True) as response:
        #     res = response.json()
        #     # 记录调用接口的时间、spu和调用后的返回数据
        #     with open('D:\测试常用系统\测试\测试报告\产品系统-侵权词商标词校验\checkbrand\data_checkbrand.txt', 'a+')as f:
        #         f.write((str(t)+'----'+spu + '\n'))
        #         f.write(str(res) + '\n')
        #     if response.status_code != 200:
        #         response.failure(res['errorMsg'])
        #     else:
        #         response.success()


    # 创建侵权词(MySQL)接口行为类
    @locust.task(1)
    def checkinfringement(self):
        '''
        # 获取数据完整的所有spu
        query_spu = "SELECT spu FROM spu_official WHERE off_complement = '1';"
        spus = Data_Sql('erp_product', '192.168.4.87', 'root', 'admin0808').data_sql('select', query_spu)
        spu = spus[random.randint(1, len(spus)-1)]
        # 拼接spu文案
        query_sql = "SELECT cn_customs, en_customs, title, amazon_title, \
                                  must_keyword, description, short_description FROM spu_official \
                                  WHERE spu = '{0}' AND off_complement = '1';".format(spu)
        sql = Data_Sql('erp_product', '192.168.4.87', 'root', 'admin0808').data_sql('select', query_sql)
        sql_filter = list(filter(None, sql))
        s = ''.join(sql_filter)
        '''
        self.url = '/commonConfig/checkInfringement'
        self.form = MultipartEncoder({"content": "{0}".format(s)})
        print("checkinfringement: {0}".format(spu))
        t = datetime.now()
        # r = self.client.post(self.url, data=self.form, headers={'Content-Type': self.form.content_type})
        # 断言接口是否报错
        with self.client.post(url=self.url, data=self.form,
                              headers={'Content-Type': self.form.content_type},
                              timeout=10, catch_response=True) as response:
            res = response.json()
            # pprint.pprint(res)
            # 记录调用接口的时间、spu和调用后的返回数据
            with open('D:\测试常用系统\测试\测试报告\产品系统-侵权词商标词校验\checkinfringement\data_checkinfringement.txt', 'a+')as f:
                f.write((str(t)+'----'+spu + '\n'))
                f.write(str(res) + '\n')
            if response.status_code == 200:
                response.success()
            else:
                response.failure()


# 调用指定类并定义调用一次后的等待时间
class ApiUser(locust.HttpUser):
    tasks = [CheckBrand_CheckinFringement]
    # 设置最大最小等待时间
    min_wait = 1000
    max_wait = 5000
    # 系统IP+端口
    # host = 'http://192.168.3.198:8883'


# 补全更新数据库SPU文案数据
def main():
    # 随机获取10个简体中文
    def chinese():
        l = []
        for i in range(10):
            china = random.randint(0x4e00, 0x9fbf)
            l.append(chr(china))
        c = ''.join(l)
        return c

    # 随机获取10为英文+数字
    def english():
        num = string.ascii_letters + string.digits
        n = ''.join(random.sample(num, 10))
        return n

    # print(len(spu_nums))

    # print(spu_num)
    # 向SPU管理数据表中插入可压测的完整数据
    def insert_data():
        print("开始同步")
        i = 0
        while i < 10:
            lis = []
            i += 1
            # 获取所有文案信息不全的spu
            spu_sql = "SELECT spu FROM spu_official WHERE off_complement = '0';"
            spus = Data_Sql('erp_product', '192.168.4.87', 'root', 'admin0808').data_sql('select', spu_sql)
            # print(len(spus))
            # 随机获取一个文案信息不全的spu
            spu_num = spus[random.randint(1, len(spus))]
            # print(spu_num)
            for a in range(12):
                lis.append(chinese())
            for b in range(19):
                lis.append(english())
            lis.append(spu_num)
            # print(lis)
            query_sql = "UPDATE spu_official \
    SET short_title1 = '{0}', short_title2 = '{1}',\
    short_title3 = '{2}', short_title4 = '{3}',\
    short_title5 = '{4}', short_title6 = '{5}',\
    short_title7 = '{6}', short_title8 = '{7}',\
    short_title9 = '{8}', short_title10 = '{9}',\
    short_title11 = '{10}', short_title12 = '{11}',\
    long_title1 = '{12}', long_title2 = '{13}',\
    long_title3 = '{14}', long_title4 = '{15}',\
    long_title5 = '{16}', long_title6 = '{17}',\
    features1 = '{18}', features2 = '{19}',\
    features3 = '{20}', features4 = '{21}',\
    features5 = '{22}', features6 = '{23}',\
    features7 = '{24}', features8 = '{25}',\
    features9 = '{26}', features10 = '{27}',\
    package_Includes = '{28}', specifications = '{29}',\
    note = '{30}', updater = '170479-马佳钦', off_complement = '1'\
    WHERE spu = '{31}';".format(*lis)
            # pprint.pprint(query_sql)
            sp = Data_Sql('erp_product', '192.168.4.87', 'root', 'admin0808').data_sql('update', query_sql)
            # print(sp)
        print("同步结束")

    s = insert_data()


if __name__ == '__main__':
    import os
    os.system('locust -f Trademark_infringement_spu.py --host=http://192.168.3.198:8883')
    # main()
