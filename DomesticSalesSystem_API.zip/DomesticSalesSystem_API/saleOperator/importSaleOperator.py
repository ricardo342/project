#!/usr/bin/python
#coding=utf8
import logging
logging.basicConfig(level=logging.DEBUG, format=' %(asctime)s - %(levelname)s- %(message)s')
# logging. disable(logging.CRITICAL)    # 禁用日志
logging.debug('Start of program')

import unittest
import requests
import json
import HTMLTestRunner
from assertpy import assert_that

from common import get_domain as c
from common import codeRespon as s
from common import organize_json as oj
domain = c.Get_Domain().Domain()

class importSaleOperator(unittest.TestCase):
    def setUp(self):
        self.url = domain + "/b2bsfa/saleOperator/importSaleOperator"
        self.headers = {'Content-Type': 'application/json'}
        
    def test_importSaleOperator(self):
        # open('exportSaleOperatorList.json', encoding = "utf-8").close()
        self.form = {'file':(importSaleOperator, open('D:\\Automated_Scripts\\员工信息.xlsx', 'rb'), 'xlsx')}
        r = requests.post(self.url, headers=self.headers, data=self.form)
        code = r.status_code
        # print(code)
        codes = oj.Organize_Json("./saleOperator/r.json", r.text).organize_json()
        print(code)
        s.codeRespon(codes)
        print(r.text)
        try:
            assert_that(codes).is_equal_to('200')
            assert_that(r.text).contains("code","data","message").is_type_of(str)
        except AssertionError as e:
            raise AssertionError(e)
       
def suite():
    suite = unittest.TestSuite()
    suite.addTest(importSaleOperator("test_importSaleOperator"))
    return suite

if __name__ == "__main__":
    # re = open("result.html", "wb")
    runner = unittest.TextTestRunner()
    runner.run(suite())
    # re.close()

logging.debug('End of program')