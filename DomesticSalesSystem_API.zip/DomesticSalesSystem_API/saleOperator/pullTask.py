#!/usr/bin/env python
# -*- coding:utf-8 -*-
# @Time     : 2020/6/2817:00
# @Author   : Dora
# @Email    : peixq@galanz.com
# 下发指标

import logging
logging.basicConfig(level=logging.DEBUG, format=' %(asctime)s - %(levelname)s- %(message)s')
# logging. disable(logging.CRITICAL)    # 禁用日志
logging.debug('Start of program')


import unittest
import requests
import json
from assertpy import assert_that

from common import get_domain as URL
from common import get_status as Gcode
from common import get_token

domain = URL.Get_Domain().Domain()

class pullTask(unittest.TestCase):
    #目标管理-指标任务接口-下发指标-/indicatorTask/pullTask
    def setUp(self):

        # self.taskId = "IT20200628000000082"
        self.url = domain+'/b2bsfa/indicatorTask/pullTask/'
        self.headers = {
            "Content-Type":"application/json;charset=UTF-8"
        }

        #print(self.url,'\n')
    def test_PullIndicator(self):
        self.form = {'taskId': 'IT20200628000000082'}
        r = requests.get(self.url,headers=self.headers, params=self.form)
        t = json.loads(r.text)
        #print(r.text,t["message"])
        #print(r.status_code)
        if r.status_code == 200:
            #print("OK")
            #if r.status_code == 200:
            try:
                assert_that(t["message"]).is_equal_to("请求成功、结果处理成功")
                n=assert_that(t["message"]).is_equal_to("请求成功、结果处理成功")
                print("待下发指标下发成功--OK--{}".format(t["message"]))
                print(n)
            except:
                self.assertEqual(t["message"],"该单据审核状态错误!")
                print("已下发指标不能再下发--OK--{}".format(t["message"]))

        else:
            get_code = Gcode.GetStatus(r.status_code)
            get_code.Notpass_status()

logging.debug('End of program')

if __name__ == '__main__':
    unittest.main()


