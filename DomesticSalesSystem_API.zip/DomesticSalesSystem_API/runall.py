#!/usr/bin/python
#coding=utf8

import HTMLTestRunner
import sys
import pprint

# sys.path.append("F:\\galanz_api\\common")

from common.suite1 import suite
from common.send_email import Send_Email


if __name__ == "__main__":
    re = open("result.html", "wb")
    runner = HTMLTestRunner.HTMLTestRunner(stream=re, title='测试报告', description='详情')
    runner.run(suite())
    re.close()

Send_Email().send_email('F:\\DomesticSalesSystem_API\\result.html')