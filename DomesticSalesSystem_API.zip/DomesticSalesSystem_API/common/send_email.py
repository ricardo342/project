#!/usr/bin/python
#coding=utf8

import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from email.header import Header

class Send_Email():

    def send_email(self, report):
        mail_host = 'mail.galanz.com'           # 设置服务器
        mail_port = 25                          # SMTP端口号
        mail_accepter = 'majq@galanz.com'      # 接收邮件的邮箱
        accepter = 'majq'                      # 接收者简称

        mail_sender = 'majq@galanz.com'         # 发送邮箱
        # mail_sender = 'yaoxs@galanz.com'
        mail_password = '06257020Ss'             # 邮箱密码

        with open('D:\\galanz_project\\DomesticSalesSystem_API\\result.html', 'rb') as file:
            mail_body = file.read()             # 正文内容
            sender = 'majq@galanz.com'
            text = MIMEText(mail_body, 'html', 'utf-8')
            """创建一个带附件的实例"""
            message = MIMEMultipart('mixed')
            message.attach(text)
        
        message['Subject'] = u'接口测试报告'
        message['From'] = sender
        message['To'] = "".join(accepter)

        try:
            s = smtplib.SMTP(mail_host, mail_port)
            s.login(mail_sender, mail_password)
            s.sendmail(sender, mail_accepter, message.as_string())
            s.close()
            print("邮件发送成功！")
            return True
        except Exception as e:
            print(e)
            return False

# Send_Email().send_email('F:\\study\\api_test_frame\\report.html')