# -*- coding:utf-8 -*-
#!/usr/bin/python3

'''
监控Amazon品类榜单-Home&Kitchen品类下所有小品类是否每天均有爬取
Best Sellers,New Release,Movers&Shakers,Most Wished For,
Gift Ideas五个榜单的数据
'''

'''
监控逻辑如下：
1.查询new_amazon_category表下的ctype和nodes获取各榜单下的子分类
2.根据拿到的ctype和nodes查询amazon_category_asin_info表下的updatedTime
3.获取amazon_category_asin_info表下各nodes对应的分类名称
4.amazon_category_asin_info.updatedTime有昨天数据则该分类昨日有爬取数据
5.若该分类amazon_category_asin_info.updatedTime无昨天数据则查询
amazon_category_asin_info中该nodes对应的categoryName，提示该子分类昨日爬取任务未执行
'''

import requests
import json
import pprint
import csv
import codecs
import time

from elasticsearch6 import Elasticsearch
from pandas import tseries
from datetime import datetime


# 调用钉钉机器人@对应负责人
class DingHelp():
    def __init__(self, message):
        global false
        false = ''
        self.message = message
        self.url = 'https://oapi.dingtalk.com/robot/send?access_token=1e8964f7d09b2c8ef23e83202c8bef226b2264a3f0e2d829cece18ef4492ada1'
        self.header = {'Content-Type': 'application/json'}
        self.form = {"msgtype": "text",
                    "text": {"content": ""},
                    "at": {"atMobiles": ["18680359498"],
                    "isAtAll": false}}
        self.form["text"]["content"] = self.message

    def dinghelp(self):
        r = requests.post(self.url, headers=self.header, data=json.dumps(self.form))
        return r.json()


'''
监控逻辑如下：
1.查询new_amazon_category表下的ctype和nodes获取各榜单下的子分类
2.根据拿到的ctype和nodes查询amazon_category_asin_info表下的updatedTime
3.获取amazon_category_asin_info表下各nodes对应的分类名称
4.amazon_category_asin_info.updatedTime有昨天数据则该分类昨日有爬取数据
5.若该分类amazon_category_asin_info.updatedTime无昨天数据则查询
amazon_category_asin_info中该nodes对应的categoryName，提示该子分类昨日爬取任务未执行
'''
class Amazon_Listing():
    def __init__(self):
        self.hosts = '10.100.1.71'
        self.port = 9200
        self.timeout = 50000

    def amazon_listing(self, index, query):
        global true
        true = ''
        self.index = index
        self.query = query

        es = Elasticsearch(hosts=self.hosts, port=self.port, timeout=self.timeout)
        allDoc = es.search(index=self.index, body=self.query)
        return allDoc['hits']

# 获取特定时间
def updatetime(date, num):
    dt = datetime.now()
    dt_date = (dt + num*tseries.offsets.Day()).strftime(date)
    return dt_date


# 将数据导出成csv文件
def file_csv(file_path, data):
    f_csv = codecs.open(file_path, 'w+', 'utf-8')
    writer = csv.writer(f_csv, delimiter=';', quotechar='"', quoting=csv.QUOTE_MINIMAL)
    for i in data:
        writer.writerow(i)


if __name__ == '__main__':
    # 获取全部子分类
    print('开始执行')
    start_time = time.time()
    son_categorys_query = {"query": {"match_all": {}},"size": 50000,"sort": [{"updatedTime": {"order": "desc"}}]}
    son_categorys = Amazon_Listing().amazon_listing("new_amazon_category", son_categorys_query)
    cates = []
    # print(son_categorys['total'])
    for i in range(10000):
        if son_categorys['hits'][i]['_source']['listNodeName'][0] == 'Home & Kitchen':
            # Node = son_categorys['hits'][i]['_source']['categoryNode']
            Name = son_categorys['hits'][i]['_source']['categoryName']
            cates.append(Name)
    cates = list(set(cates))
    cates_num = len(cates)
    # cates_dict = dict(cates)
    # pprint.pprint(cates)
    print(len(cates))
    # 获取全部站点
    asin_info_query = {"query": {"match_all": {}},"size": 10000}
    asin_info = Amazon_Listing().amazon_listing('amazon_category_asin_info', asin_info_query)
    # countrys = ['US', 'CA', 'BR', 'MX', 'UK', 'FR', 'DE', 'IT', 'ES', 'TR', 'JP', 'IN', 'AU', 'CN']
    countrys = []
    for j in range(10000):
        coun = son_categorys['hits'][j]['_source']['country']
        countrys.append(coun)
    countrys = list(set(countrys))
    # pprint.pprint(countrys)
    # 获取全部分类类型
    ctypes = [2, 3, 4, 5, 6]
    # 查询哪些子分类没有正常执行爬取任务
    amazon_categorys_task_query = {"query": {
                                      "bool": {
                                        "must": [
                                          {"match": {"country": "US"}},
                                          {"match": {"categoryName": "Bath"}},
                                          {"match": {"ctype": "2"}}
                                        ]}},
                                      "sort": [
                                        {
                                          "updatedTime": {"order": "desc"}}],
                                      "size": 10000}
    # 获取爬取任务有问题的子分类信息(country, nodes, ctype)
    task_error = []
    for a in countrys:
        for b in cates:
            for c in ctypes:
                amazon_categorys_task_query["query"]["bool"]["must"][0]["match"]["country"] = a
                amazon_categorys_task_query["query"]["bool"]["must"][1]["match"]["categoryName"] = b
                amazon_categorys_task_query["query"]["bool"]["must"][2]["match"]["ctype"] = c
                task_query = amazon_categorys_task_query
                amazon_categorys_task = Amazon_Listing().amazon_listing('amazon_category_asin_info', task_query)
                # 判断该子分类下是否有数据
                if amazon_categorys_task['total'] == 0:
                    task_error_query = {"query": {"match": {"categoryName": "TEXT"}},"size": 10000}
                    task_error_query["query"]["match"]["categoryName"] = b
                    b1 = Amazon_Listing().amazon_listing('amazon_category_asin_info', task_error_query)
                    if b1['total'] == 0:
                        continue
                    else:
                        b2 = b1['hits'][0]['_source']['nodes']
                        task_error.append((a, b2, c))
                else:
                    # 监控该子分类昨天是否运行了爬取任务
                    yesterday = updatetime('%Y-%m-%d', -1)
                    # print(yesterday)
                    task_time = amazon_categorys_task['hits'][0]['_source']['updatedTime']
                    # print(task_time)
                    if task_time[0:10] != yesterday:
                        country = amazon_categorys_task['hits'][0]['_source']['country']
                        nodes = amazon_categorys_task['hits'][0]['_source']['nodes']
                        ctype = amazon_categorys_task['hits'][0]['_source']['ctype']
                        task_error.append((country, nodes, ctype))
    if len(task_error) == 0:
        msg1 = 'Amazon品类榜单-Home&Kitchen品类下有{0}个小品类，共计{1}个爬取任务，任务均正常进行'.format(cates_num, cates_num*len(ctypes))
        # print(msg1)
        DingHelp(msg1).dinghelp()
    else:
        # file_csv('D:\测试常用系统\数据分析系统\爬取任务异常数据\error_{0}.csv'.format(updatetime('%y%m%d', 0)), task_error)
        file_csv('/var/ftp/pub/Das/error_{0}.csv'.format(updatetime('%y%m%d', 0)), task_error)
        msg2 = 'Amazon品类榜单-Home&Kitchen品类下有{0}个小品类,共计{1}个爬取任务,有{2}个任务异常，异常数据文件如下：ftp://192.168.3.180/pub/Das/(查询最新日期文件)'.format(cates_num, cates_num*len(ctypes), len(task_error))
        # print(msg2)
        DingHelp(msg2).dinghelp()
    # end_time = time.time()
    # print('程序结束， 共花费{:.2f}秒'.format(end_time-start_time))