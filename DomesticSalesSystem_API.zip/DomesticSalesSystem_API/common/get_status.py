#!/usr/bin/env python
# -*- coding:utf-8 -*-
# @Time     : 2020/6/2916:31
# @Author   : Dora
# @Email    : peixq@galanz.com
class GetStatus():
    def __init__(self,code):
        self.code = code
    def Notpass_status(self):
        if self.code == 404:
            print("Not Found--{}".format(self.code))
        elif self.code == 500:
            print("Internal Server Error--{}".format(self.code))
        elif self.code == 401:
            print("Unauthorized--{}".format(self.code))
        elif self.code == 403:
            print("Forbidden--{}".format(self.code))
        elif self.code == 400:
            print("Bad Request--{}".format(self.code))
        elif self.code == 502:
            print("Bad Gateway--{}".format(self.code))
        elif self.code == 503:
            print("Server Unavailable--{}".format(self.code))
        else:
            print("ERROR:{}".format(self.code))


    def pass_status(self):
        if self.code == 200:
            print("OK!--{}".format(self.code))

