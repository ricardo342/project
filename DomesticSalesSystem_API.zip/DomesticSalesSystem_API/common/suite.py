#!/usr/bin/python
#coding=utf8

import unittest
import HTMLTestRunner
import sys
#sys.path.append("F:\\api_test\\DomesticSalesSystem_API\\indicatorTaskSpeed")

# MODULE: indicatorTaskSpeed
# CASE NUM: 19
from indicatorTaskSpeed import audit
#import indicatorTaskSpeed.audit
#import audit

from indicatorTaskSpeed import queryEntityById
from indicatorTaskSpeed import queryPage
from indicatorTaskSpeed import queryPageTaskSpeedFive
from indicatorTaskSpeed import queryPageTaskSpeedFour
from indicatorTaskSpeed import queryPageTaskSpeedThree
from indicatorTaskSpeed import queryPageTaskSpeedTwo
from indicatorTaskSpeed import queryPageTaskSpeedOne
from indicatorTaskSpeed import qureyStoreInfo
from indicatorTaskSpeed import syncLadingUpdateSpeed
from indicatorTaskSpeed import upLoadData
from indicatorTaskSpeed import deleteEntityById
from indicatorTaskSpeed import exportPageTaskSpeedFive
from indicatorTaskSpeed import exportPageTaskSpeedFour
from indicatorTaskSpeed import exportPageTaskSpeedOne
from indicatorTaskSpeed import exportPageTaskSpeedThree
from indicatorTaskSpeed import exportPageTaskSpeedTwo
from indicatorTaskSpeed import queryByProductGroup
from indicatorTaskSpeed import queryProductClass
from indicatorTaskSpeed import uploadDataForm

# MODULE: indicatorStatistics
# CASE NUM: 10
from indicatorStatistics import businessManagerIndicatorStatistics
from indicatorStatistics import exportBusIndicatorStatisticsList
from indicatorStatistics import exportMarketingIndicatorStatisticsList
from indicatorStatistics import exportRegionIndicatorStatisticsList
from indicatorStatistics import findBusIndicatorStatisticsList
from indicatorStatistics import findMarketingIndicatorStatisticsList
from indicatorStatistics import findRegionIndicatorStatisticsList
from indicatorStatistics import marketingIndicatorStatistics
from indicatorStatistics import regionIndicatorStatistics
from indicatorStatistics import singleBusinessManagerIndicatorStatistics

from saleOperator import batchUpdateSaleOperator
from saleOperator import delDealerSaleOperator
from saleOperator import importSaleOperator
from saleOperator import delSaleOperator
from saleOperator import exportSaleOperatorList
from saleOperator import findConstant
from saleOperator import findDealerCustomerByMobile
from saleOperator import findSaleOperator
from saleOperator import findSaleOperatorByJobNo
from saleOperator import findSaleOperatorByMobile
from saleOperator import findSaleOperatorList
from saleOperator import findSaleOrgTree
from saleOperator import saveSaleOperator

from store import addStores

from taskJob import improtExcel
from taskJob import queryJobList
from taskJob import queryReport


def suite():
    suite = unittest.TestSuite()
    suite.addTest(audit.audit("test_audit"))
    suite.addTest(queryEntityById.queryEntityById("test_queryEntityById"))
    suite.addTest(queryPage.queryPage("test_queryPage"))
    suite.addTest(queryPageTaskSpeedFive.queryPageTaskSpeedFive("test_queryPageTaskSpeedFive"))
    suite.addTest(queryPageTaskSpeedFour.queryPageTaskSpeedFour("test_queryPageTaskSpeedFour"))
    suite.addTest(queryPageTaskSpeedThree.queryPageTaskSpeedThree("test_queryPageTaskSpeedThree"))
    suite.addTest(queryPageTaskSpeedTwo.queryPageTaskSpeedTwo("test_queryPageTaskSpeedTwo"))
    suite.addTest(queryPageTaskSpeedOne.queryPageTaskSpeedOne("test_queryPageTaskSpeedOne"))
    suite.addTest(qureyStoreInfo.qureyStoreInfo("test_qureyStoreInfo"))
    suite.addTest(syncLadingUpdateSpeed.syncLadingUpdateSpeed("test_syncLadingUpdateSpeed"))
    suite.addTest(upLoadData.upLoadData("test_upLoadData"))
    suite.addTest(businessManagerIndicatorStatistics.businessManagerIndicatorStatistics("test_businessManagerIndicatorStatistics"))
    suite.addTest(exportBusIndicatorStatisticsList.exportBusIndicatorStatisticsList("test_exportBusIndicatorStatisticsList"))
    suite.addTest(exportMarketingIndicatorStatisticsList.exportMarketingIndicatorStatisticsList("test_exportMarketingIndicatorStatisticsList"))
    suite.addTest(exportRegionIndicatorStatisticsList.exportRegionIndicatorStatisticsList("test_exportRegionIndicatorStatisticsList"))
    suite.addTest(findBusIndicatorStatisticsList.findBusIndicatorStatisticsList("test_findBusIndicatorStatisticsList"))
    suite.addTest(findMarketingIndicatorStatisticsList.findMarketingIndicatorStatisticsList("test_findMarketingIndicatorStatisticsList"))
    suite.addTest(findRegionIndicatorStatisticsList.findRegionIndicatorStatisticsList("test_findRegionIndicatorStatisticsList")) 
    suite.addTest(marketingIndicatorStatistics.marketingIndicatorStatistics("test_marketingIndicatorStatistics"))
    suite.addTest(regionIndicatorStatistics.regionIndicatorStatistics("test_regionIndicatorStatistics"))
    suite.addTest(deleteEntityById.deleteEntityById("test_deleteEntityById"))
    suite.addTest(exportPageTaskSpeedFive.exportPageTaskSpeedFive("test_exportPageTaskSpeedFive"))
    suite.addTest(exportPageTaskSpeedFour.exportPageTaskSpeedFour("test_exportPageTaskSpeedFour"))
    suite.addTest(exportPageTaskSpeedOne.exportPageTaskSpeedOne("test_exportPageTaskSpeedOne"))
    suite.addTest(exportPageTaskSpeedThree.exportPageTaskSpeedThree("test_exportPageTaskSpeedThree"))
    suite.addTest(exportPageTaskSpeedTwo.exportPageTaskSpeedTwo("test_exportPageTaskSpeedTwo"))
    suite.addTest(queryByProductGroup.queryByProductGroup("test_queryByProductGroup"))
    suite.addTest(queryProductClass.queryProductClass("test_queryProductClass"))
    suite.addTest(singleBusinessManagerIndicatorStatistics.singleBusinessManagerIndicatorStatistics("test_singleBusinessManagerIndicatorStatistics"))
    suite.addTest(uploadDataForm.uploadDataForm("test_uploadDataForm"))
    suite.addTest(batchUpdateSaleOperator.batchUpdateSaleOperator("test_batchUpdateSaleOperator"))
    # suite.addTest(delDealerSaleOperator.delDealerSaleOperator("test_delDealerSaleOperator"))
    suite.addTest(delSaleOperator.delSaleOperator("test_delSaleOperator"))
    suite.addTest(exportSaleOperatorList.exportSaleOperatorList("test_exportSaleOperatorList"))
    suite.addTest(findConstant.findConstant("test_findConstant"))
    suite.addTest(findDealerCustomerByMobile.findDealerCustomerByMobile("test_findDealerCustomerByMobile"))
    suite.addTest(findSaleOperator.findSaleOperator("test_findSaleOperator"))
    suite.addTest(findSaleOperatorByJobNo.findSaleOperatorByJobNo("test_findSaleOperatorByJobNo"))
    suite.addTest(findSaleOperatorByMobile.findSaleOperatorByMobile("test_findSaleOperatorByMobile"))
    suite.addTest(findSaleOperatorList.findSaleOperatorList("test_findSaleOperatorList"))
    suite.addTest(findSaleOrgTree.findSaleOrgTree("test_findSaleOrgTree"))
    suite.addTest(importSaleOperator.importSaleOperator("test_importSaleOperator"))
    suite.addTest(saveSaleOperator.saveSaleOperator("test_saveSaleOperator"))
    suite.addTest(addStores.addStores("test_addStores"))
    suite.addTest(improtExcel.improtExcel("test_improtExcel"))
    suite.addTest(queryJobList.queryJobList("test_queryJobList"))
    suite.addTest(queryReport.queryReport("test_queryReport"))
    # suite.addTest()

    return suite
'''
if __name__ == "__main__":
    re = open("result.html", "wb")
    runner = HTMLTestRunner.HTMLTestRunner(stream=re, title='测试报告', description='详情')
    runner.run(suite())
    re.close()
'''